/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
    public class Message {

    private final String messageText;

    public Message(String recipient, String messageText) {
        this.messageText = messageText;
    }

    public String checkMessageLength() {
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = messageText.length() - 250;

            return "Message exceeds 250 characters by "
                    + excess
                    + ", please reduce the size.";
        }
    }
}