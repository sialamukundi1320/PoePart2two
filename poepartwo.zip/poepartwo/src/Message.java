/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public final class Message {

    private static final SecureRandom RANDOM = new SecureRandom();

    // Keeps messages in memory while the application runs.
    private static final List<Message> sentMessages = new ArrayList<>();

    private static int messageCounter = 0;

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String messageHash;

    private String status;

    public Message(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageNumber = messageCounter;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
        this.status = "Pending";
    }

    private String generateMessageID() {
        // Generate a number with exactly ten digits.
        long id = 1_000_000_000L
                + RANDOM.nextLong(9_000_000_000L);

        return String.valueOf(id);
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        // Assignment rule: maximum 10 characters,
        // international prefix, followed by digits.
        if (recipient != null
                && recipient.length() <= 10
                && recipient.matches("\\+[1-9][0-9]+")) {

            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted "
                + "or does not contain an international code. "
                + "Please correct the number and try again";
    }

    public String checkMessageLength() {
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        }

        int excess = messageText.length() - 250;

        return "Message exceeds 250 characters by "
                + excess + "; please reduce the size.";
    }

    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        String firstTwoIDDigits = messageID.substring(0, 2);

        return (firstTwoIDDigits + ":"
                + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    public String SentMessage(String choice) {
        if (choice == null) {
            return "Invalid choice.";
        }

        switch (choice.trim().toLowerCase()) {
            case "send" -> {
                if (!"Message ready to send.".equals(checkMessageLength())
                        || !checkRecipientCell().startsWith(
                                "Cell phone number successfully")) {
                    return "Message could not be sent. Check the recipient "
                            + "and message length.";
                }

                status = "Sent";
                sentMessages.add(this);
                messageCounter++;

                return "Message successfully sent.";
            }

            case "disregard", "discard" -> {
                status = "Disregarded";
                return "Press 0 to delete the message.";
            }
            case "store" -> {
                try {
                    storeMessage();
                    status = "Stored";
                    return "Message successfully stored.";
                } catch (IOException ex) {
                    return "Could not store message: " + ex.getMessage();
                }
            }

            default -> {
                return "Invalid choice. Choose send, disregard, or store.";
            }
        }
    }

    public String SentMessage() {
        Scanner input = new Scanner(System.in);

        System.out.println("Choose an option:");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");

        String choice = input.nextLine();

        return switch (choice) {
            case "1" -> SentMessage("send");
            case "2" -> SentMessage("disregard");
            case "3" -> SentMessage("store");
            default -> "Invalid choice.";
        };
    }

    public void storeMessage() throws IOException {
        Path file = Paths.get("messages.json");

        String json = "{"
                + "\"messageID\":\"" + escapeJSON(messageID) + "\","
                + "\"messageNumber\":" + messageNumber + ","
                + "\"messageHash\":\"" + escapeJSON(messageHash) + "\","
                + "\"recipient\":\"" + escapeJSON(recipient) + "\","
                + "\"message\":\"" + escapeJSON(messageText) + "\","
                + "\"status\":\"Stored\""
                + "}\n";

        Files.write(
                file,
                json.getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND
        );
    }

    private String escapeJSON(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent.";
        }

        StringBuilder output = new StringBuilder();

        for (Message msg : sentMessages) {
            output.append("Message ID: ")
                    .append(msg.messageID).append("\n");

            output.append("Message Hash: ")
                    .append(msg.messageHash).append("\n");

            output.append("Recipient: ")
                    .append(msg.recipient).append("\n");

            output.append("Message: ")
                    .append(msg.messageText).append("\n\n");
        }

        return output.toString();
    }

    public int returnTotalMessagess() {
        return sentMessages.size();
    }

    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getStatus() {
        return status;
    }
}