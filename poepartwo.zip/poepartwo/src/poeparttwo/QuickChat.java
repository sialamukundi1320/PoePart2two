/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * to change this license
 */
 /**
 *@author Student
 */       
 package poepartone;

import java.util.Scanner;

public class QuickChat {

    public static void startAfterLogin() {

        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to QuickChat.");

        System.out.print("How many messages would you like to enter? ");

        int messageLimit = Integer.parseInt(input.nextLine());

        int messagesEntered = 0;

        boolean running = true;

        while (running) {

            System.out.println("\n1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");

            System.out.print("Choose an option: ");
            String option = input.nextLine();

            switch (option) {

                case "1" -> {
                    if (messagesEntered >= messageLimit) {
                        System.out.println(
                                "You have reached your message limit."
                        );
                        break;
                    }

                    System.out.print("Recipient number: ");
                    String recipient = input.nextLine();

                    System.out.print("Enter message: ");
                    String text = input.nextLine();

                    Message message = new Message(recipient, text);

                    if (!message.checkRecipientCell().startsWith(
                            "Cell phone number successfully")) {
                        System.out.println(
                                message.checkRecipientCell()
                        );
                        break;
                    }

                    if (!message.checkMessageLength().equals(
                            "Message ready to send.")) {
                        System.out.println(
                                "Please enter a message of less than 250 characters."
                        );
                        break;
                    }

                    System.out.println("Message ready to send.");

                    System.out.println("1. Send Message");
                    System.out.println("2. Disregard Message");
                    System.out.println("3. Store Message to send later");

                    System.out.print("Choose: ");
                    String choice = input.nextLine();

                switch (choice) {
                    case "1" -> {
                        System.out.println(
                                message.SentMessage("send")
                        );
                        System.out.println("Message ID: "
                                + message.getMessageID());
                        System.out.println("Message Hash: "
                                + message.getMessageHash());
                        System.out.println("Recipient: "
                                + message.getRecipient());
                        System.out.println("Message: "
                                + message.getMessageText());
                        messagesEntered++;
                    }
                    case "2" -> {
                        System.out.println(
                                message.SentMessage("disregard")
                        );
                        messagesEntered++;
                    }
                    case "3" -> {
                        System.out.println(
                                message.SentMessage("store")
                        );
                        messagesEntered++;
                    }
                    default -> System.out.println("Invalid choice.");
                }
                }

                case "2" -> System.out.println("Coming Soon.");

                case "3" -> {
                    running = false;
                    System.out.println("Goodbye!");
                }

                default -> System.out.println("Invalid option.");
            }
        }

        Message manager = new Message("+271234567", "Hello");

        System.out.println("Total messages sent: "
                + manager.returnTotalMessagess());
    }
}