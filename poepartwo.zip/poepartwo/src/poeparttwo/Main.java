/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poepartone;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login login = new Login();

        System.out.println("Please log in.");

        System.out.print("Username: ");
        String username = input.nextLine();

        System.out.print("Password: ");
        String password = input.nextLine();

        boolean loginSuccessful =
                login.loginUser(username, password);

        System.out.println(
                login.returnLoginStatus(loginSuccessful)
        );

        if (loginSuccessful) {
            QuickChat.startAfterLogin();
        } else {
            System.out.println(
                    "You must log in successfully to send messages."
            );
        }
    }
}