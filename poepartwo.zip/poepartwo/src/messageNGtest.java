/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class MessageNGTest {

    @Test
    public void testMessageLengthSuccess() {
        Message message = new Message(
                "+271234567",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                message.checkMessageLength(),
                "Message ready to send."
        );
    }

    @Test
    public void testMessageLengthFailure() {
        String longText = "A".repeat(251);

        Message message = new Message(
                "+271234567",
                longText
        );

        assertEquals(
                message.checkMessageLength(),
                "Message exceeds 250 characters by 1, please reduce the size."
        );
    }
}