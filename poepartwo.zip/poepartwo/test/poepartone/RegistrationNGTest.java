/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package poepartone;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Student
 */
public class RegistrationNGTest {
    
    public RegistrationNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of checkUserName method, of class Registration.
     */
    @Test
public void testCheckUserName() {
    System.out.println("checkUserName");
    String username = "";
    Registration instance = new Registration();
    boolean expResult = false;
    boolean result = instance.checkUserName(username);
    assertEquals(expResult, result);
}
    /**
     * Test of checkPasswordComplexity method, of class Registration.
     */
   @Test
public void testCheckPasswordComplexity() {
    System.out.println("checkPasswordComplexity");
    String password = "";
    Registration instance = new Registration();
    boolean expResult = false;
    boolean result = instance.checkPasswordComplexity(password);
    assertEquals(expResult, result);
}

    /**
     * Test of checkCellPhoneNumber method, of class Registration.
     */
    @Test
public void testCheckCellPhoneNumber() {
    System.out.println("checkCellPhoneNumber");
    String cellphone = "";
    Registration instance = new Registration();
    boolean expResult = false;
    boolean result = instance.checkCellPhoneNumber(cellphone);
    assertEquals(expResult, result);
}

    /**
     * Test of registerUser method, of class Registration.
     */
    @Test
public void testRegisterUser() {
    System.out.println("registerUser");
    String username = "";
    String password = "";
    String cellphone = "";

    Registration instance = new Registration();

    String expResult = "Registration was umsuccessfull";
    String result = instance.registerUser(username, password, cellphone);

    assertEquals(expResult, result);
}
    /**
     * Test of registerStatus method, of class Registration.
     */
    @Test
public void testRegisterStatus() {
    System.out.println("registerStatus");

    String username = "user@123";
    String password = "Password1!";
    String cellphone = "0831234567";

    Registration instance = new Registration();

    boolean expResult = true;
    boolean result = instance.registerStatus(username, password, cellphone);

    assertEquals(expResult, result);
}
    
}
