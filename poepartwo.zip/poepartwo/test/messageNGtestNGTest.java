/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */

import static org.testng.Assert.*;

/**
 *
 * @author Student
 */
public class messageNGtestNGTest {
    
    public messageNGtestNGTest() {
    }
    
}
@Test
public void testMessageLengthSuccess() {

    Message message = new Message(
        "+27718693002",
        "Hi Mike, can you join us for dinner tonight?"
    );

    assertEquals(
        message.checkMessageLength(),
        "Message ready to send."
    );
}

@Test
public void testMessageLengthFailure() {

    String longText = "A".repeat(251);

    Message message = new Message(
        "+27718693002",
        longText
    );

    assertEquals(
        message.checkMessageLength(),
        "Message exceeds 250 characters by 1; please reduce the size."
    );
}